import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Homepage from './components/homepage/Homepage';
import Dashboard from './AdminPanel/dashboard/Dashboard';
import Login from './components/login/Login';
import Student from './AdminPanel/Student/Student';
import Studentdetail from './AdminPanel/Student/Studentdetail';
import AddNotice from './AdminPanel/NoticeBoard/AddNotice';
import AddAlbum from './AdminPanel/Album/AddAlbum';
import AddImages from './AdminPanel/Gallery/AddImages';
import AddFaculty from './AdminPanel/Faculty/AddFaculty';
import AddFeeStructure from './AdminPanel/FeeStructure/AddFeeStructure';

function App() {


  return (
    <div className="App">
      {localStorage.getItem('token') ?
        <>
          <BrowserRouter>
            <Routes>
              <Route path="" element={<Homepage />}>
                
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="addnotice" element={<AddNotice />} />
                <Route path="addalbum" element={<AddAlbum />} />
                <Route path="addimages" element={<AddImages />} />
                <Route path="addfaculty" element={<AddFaculty />} />
                <Route path="addfeestr" element={<AddFeeStructure />} />
                <Route path="student" element={<Student />} />
                <Route path="student/detail/:studentId" element={<Studentdetail />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </>
        :
        <>
          <Login />
        </>
      }

    </div>
  );
}
export default App;
