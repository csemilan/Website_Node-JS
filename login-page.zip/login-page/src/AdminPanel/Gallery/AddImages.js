import React from 'react'

const AddImages = () => {
  return (
    <div>
      add images
    </div>
  )
}

export default AddImages
