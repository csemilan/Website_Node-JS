import React from 'react'

const ImageList = () => {
  return (
    <div>
      image list
    </div>
  )
}

export default ImageList
