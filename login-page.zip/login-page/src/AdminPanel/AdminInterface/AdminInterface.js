import React from 'react'

const AdminInterface = () => {
    return (
        <div>
          <Homepage/>
        </div>
    )
}

export default AdminInterface
