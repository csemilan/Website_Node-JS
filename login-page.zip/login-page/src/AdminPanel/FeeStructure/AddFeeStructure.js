import React from 'react'

const AddFeeStructure = () => {
  return (
    <div>
      Add fees
    </div>
  )
}

export default AddFeeStructure
