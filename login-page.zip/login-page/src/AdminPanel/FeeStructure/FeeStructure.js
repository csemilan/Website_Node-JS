import React from 'react'

const FeeStructure = () => {
  return (
    <div>
      list of FeeStructure
    </div>
  )
}

export default FeeStructure
