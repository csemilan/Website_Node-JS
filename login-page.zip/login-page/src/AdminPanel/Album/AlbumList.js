import React from 'react'

const AlbumList = () => {
  return (
    <div>
      edit album
    </div>
  )
}

export default AlbumList
