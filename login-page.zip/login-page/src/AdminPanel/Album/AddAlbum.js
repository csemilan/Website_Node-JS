import React from 'react'

const AddAlbum = () => {
  return (
    <div>
      add album
    </div>
  )
}

export default AddAlbum
