import React from 'react'

const AddNotice = () => {
  return (
    <div>
      add notice
    </div>
  )
}

export default AddNotice
