import React from 'react'

const NoticeList = () => {
  return (
    <div>
      notice list
    </div>
  )
}

export default NoticeList
