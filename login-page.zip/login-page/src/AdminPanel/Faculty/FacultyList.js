import React from 'react'

const FacultyList = () => {
  return (
    <div>
      faculty list
    </div>
  )
}

export default FacultyList
