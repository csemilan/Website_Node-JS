import React from 'react'

const AddFaculty = () => {
  return (
    <div>
      add faculty
    </div>
  )
}

export default AddFaculty
