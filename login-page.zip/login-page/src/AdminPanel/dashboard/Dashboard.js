import React from 'react'


const Dashboard = () => {

  return (
    <div>
      <div class="card">
        <img src="..." class="card-img-top" alt="..." />
        <div class="card-body">
          <h5 class="card-title">Total Students</h5>
          <p class="card-text"></p>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
